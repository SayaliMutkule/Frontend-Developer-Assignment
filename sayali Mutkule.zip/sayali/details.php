<?php
	
	include_once('db/dbconnect.php');

	$s=$_GET['s'];

	$sql="SELECT * FROM `movie` WHERE moviename='$s'";
	$run=mysqli_query($con,$sql);
?>

<!DOCTYPE html>
<html>
<head>

	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Movies</title>

	<!-- custom css -->
	<link rel="stylesheet" type="text/css" href="css/custom.css">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
</head>
<body>
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="#">Movies</a>
		  </div>
		</nav>

		<!-- main container starts here -->
		<div class="container mt-5">

			<?php

				while ($rows=mysqli_fetch_assoc($run)) {
				
			?>



			<div class="row">
				<div class="col-md-4">
					<img src="db/upload/<?php echo $rows['images'] ?>" width="100%" height="100%">
				</div>
				<div class="col-md-8">
					Title:<?php echo $rows['moviename']; ?><br>
					Summary: <?php echo $rows['summary']; ?>
				</div>
				
			</div>

			<?php

				}

			?>


		</div>

		<script>
	      function openForm() {
	        document.getElementById("popupForm").style.display = "block";
	      }
	      function closeForm() {
	        document.getElementById("popupForm").style.display = "none";
	      }
	    </script>
		
	</body>
</html>