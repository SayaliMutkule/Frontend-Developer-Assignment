<?php

	include_once('dbconnect.php');


	$title=$_POST['title'];
	$summary=$_POST['summary'];

	$image=$_FILES['images']['name'];
	$file_type=$_FILES['images']['type'];
	$file_size=$_FILES['images']['size'];
	$file_tem_loc=$_FILES['images']['tmp_name'];
	$uploads="upload/".$image;

	$sql="INSERT INTO `movie`(`moviename`, `summary`, `images`) VALUES ('$title','$summary','$image')";
	
	$run=mysqli_query($con,$sql);
	if($run== TRUE)
	{
		move_uploaded_file($file_tem_loc,$uploads);
		header("location:../index.php");
	}
?>